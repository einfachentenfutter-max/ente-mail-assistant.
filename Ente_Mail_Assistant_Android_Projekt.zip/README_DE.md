# Ente Mail Assistant – Android-Projekt

Ein Android-Prototyp für ein tägliches Outlook.com-Morgenbriefing. Er liest E-Mails über Microsoft Graph (`Mail.Read`), stuft sie anhand einfacher Regeln ein und verändert keine Nachrichten.

## Wichtig: Noch kein installierbares APK
Dies ist der Quellcode. Zum Erzeugen einer APK muss das Projekt mit Android SDK/Gradle gebaut und mit einer passenden Microsoft-App-Registrierung konfiguriert werden. Ein APK wurde hier nicht gebaut oder getestet.

## Microsoft-Konto vorbereiten
1. Im Browser auf dem Tablet `https://entra.microsoft.com/` öffnen.
2. App registrations / App-Registrierungen → New registration.
3. Unterstützte Kontotypen: **Personal Microsoft accounts only** (oder Organisationskonten + persönliche Konten).
4. Plattform Android hinzufügen und Paketname `de.ente.mailassistant` verwenden.
5. Nach dem Signieren muss der Signatur-Hash eingetragen werden. Der Platzhalter `REPLACE_WITH_SIGNATURE_HASH` in `msal_config.json` und `AndroidManifest.xml` muss ersetzt werden.
6. API permissions: Microsoft Graph → Delegated permissions → `Mail.Read` und `User.Read`. Keine Schreibberechtigungen hinzufügen.
7. Client-ID in `app/src/main/res/raw/msal_config.json` eintragen.

Die Android-Plattform-Registrierung erzeugt die korrekte Redirect-URI und Signaturkonfiguration. Übernimm die Werte exakt aus dem Microsoft-Portal.

## Build
Mit Android Studio/Android SDK:
- Gradle JDK 17
- Android Gradle Plugin 8.7.3
- `./gradlew assembleDebug`
- APK liegt danach unter `app/build/outputs/apk/debug/app-debug.apk`

## Nutzung
1. App installieren und öffnen.
2. Benachrichtigungen erlauben.
3. Mit Outlook verbinden und Microsoft-Zustimmung bestätigen.
4. „Tägliche Prüfung um 07:00 aktivieren“ antippen.
5. Samsung-Einstellungen → Akku → Hintergrundnutzung / Uneingeschränkte Nutzung: App nicht in den Tiefschlaf versetzen.

## Grenzen / Datenschutz
- Die Einordnung ist regelbasiert, keine KI und kann falsch liegen.
- Die App fordert nur Leserechte an und löscht/verschiebt/markiert nichts.
- Android kann Alarme durch Energiesparmodi verzögern. Exakte Alarme benötigen ggf. die Sonderfreigabe „Alarme und Erinnerungen“.
- Der Prototyp zeigt im Vordergrund nach dem Login eine Zusammenfassung; der tägliche Hintergrundlauf nutzt einen stillen Token-Abruf. Das muss auf dem Zielgerät getestet werden.
- Für einen produktiven Einsatz sind Fehlerbehandlung, sichere Token-Verwaltung, Datenschutzinformationen und Tests nötig.
