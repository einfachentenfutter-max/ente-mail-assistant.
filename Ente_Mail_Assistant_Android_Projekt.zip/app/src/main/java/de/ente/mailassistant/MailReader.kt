package de.ente.mailassistant

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException

object MailReader {
    private val client = OkHttpClient()

    fun fetchUnreadSummary(token: String, callback: (String) -> Unit) {
        val request = Request.Builder()
            .url("https://graph.microsoft.com/v1.0/me/messages?$top=30&$orderby=receivedDateTime%20desc&$select=subject,from,receivedDateTime,importance,isRead,bodyPreview")
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/json")
            .build()
        Thread {
            try {
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        callback("Abruf fehlgeschlagen (HTTP ${response.code}). Bitte Konto/Berechtigung prüfen.")
                        return@Thread
                    }
                    val root = JSONObject(response.body?.string() ?: "{}")
                    val messages = root.optJSONArray("value")
                    val important = mutableListOf<String>()
                    val other = mutableListOf<String>()
                    if (messages != null) {
                        for (i in 0 until messages.length()) {
                            val m = messages.getJSONObject(i)
                            val subject = m.optString("subject", "(ohne Betreff)")
                            val sender = m.optJSONObject("from")?.optJSONObject("emailAddress")?.optString("address", "") ?: ""
                            val preview = m.optString("bodyPreview", "")
                            val high = m.optString("importance") == "high"
                            val keywords = listOf("frist", "termin", "dringend", "wichtig", "prüfung", "praktikum", "bewerbung", "rechnung", "behörde", "schule", "meeting")
                            val ruleMatch = (subject + " " + preview).lowercase().let { text -> keywords.any { text.contains(it) } }
                            val line = "• $subject — $sender"
                            if (high || ruleMatch) important.add(line) else other.add(line)
                        }
                    }
                    val summary = buildString {
                        append("WICHTIG (${important.size})\n")
                        append(important.take(15).joinToString("\n").ifBlank { "Keine nach den Regeln erkannten wichtigen Nachrichten." })
                        append("\n\nWEITERE (${other.size})\n")
                        append(other.take(8).joinToString("\n").ifBlank { "Keine weiteren Nachrichten." })
                        append("\n\nHinweis: Es wurden keine E-Mails geändert.")
                    }
                    callback(summary)
                }
            } catch (e: IOException) {
                callback("Netzwerkfehler: ${e.message}")
            } catch (e: Exception) {
                callback("Fehler bei der Auswertung: ${e.message}")
            }
        }.start()
    }
}
