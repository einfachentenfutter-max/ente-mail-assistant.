package de.ente.mailassistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.microsoft.identity.client.*
import com.microsoft.identity.client.exception.MsalException

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private var msal: ISingleAccountPublicClientApplication? = null
    private val scopes = arrayOf("https://graph.microsoft.com/Mail.Read", "https://graph.microsoft.com/User.Read")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermission()

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 64, 48, 48)
        }
        status = TextView(this).apply {
            textSize = 17f
            text = "Ente Mail Assistant\n\nNoch nicht verbunden."
        }
        val connect = Button(this).apply { text = "Mit Microsoft Outlook verbinden" }
        val schedule = Button(this).apply { text = "Tägliche Prüfung um 07:00 aktivieren" }
        layout.addView(status)
        layout.addView(connect)
        layout.addView(schedule)
        setContentView(layout)

        PublicClientApplication.createSingleAccountPublicClientApplication(
            applicationContext, R.raw.msal_config,
            object : IPublicClientApplication.ISingleAccountApplicationCreatedListener {
                override fun onCreated(application: ISingleAccountPublicClientApplication) {
                    msal = application
                    application.getCurrentAccountAsync(object : ISingleAccountPublicClientApplication.CurrentAccountCallback {
                        override fun onAccountLoaded(activeAccount: IAccount?) {
                            status.text = if (activeAccount != null) "Mit Microsoft verbunden: ${activeAccount.username}\n\nBerechtigung: nur E-Mails lesen." else "Noch nicht verbunden."
                        }
                        override fun onAccountChanged(priorAccount: IAccount?, currentAccount: IAccount?) {}
                        override fun onError(exception: MsalException) { status.text = "Anmeldung konnte nicht geladen werden: ${exception.message}" }
                    })
                }
                override fun onError(exception: MsalException) { status.text = "MSAL-Konfiguration prüfen: ${exception.message}" }
            })

        connect.setOnClickListener {
            val app = msal ?: run { status.text = "Microsoft-Anmeldung wird noch vorbereitet."; return@setOnClickListener }
            app.signIn(this, null, scopes, object : AuthenticationCallback {
                override fun onSuccess(result: IAuthenticationResult) {
                    status.text = "Verbunden mit ${result.account.username}.\nNur Leserechte für E-Mails."
                    MailReader.fetchUnreadSummary(result.accessToken) { summary ->
                        runOnUiThread { status.append("\n\n" + summary) }
                    }
                }
                override fun onError(exception: MsalException) { status.text = "Anmeldung fehlgeschlagen: ${exception.message}" }
                override fun onCancel() { status.text = "Anmeldung abgebrochen." }
            })
        }
        schedule.setOnClickListener {
            MorningScheduler.schedule(this)
            status.append("\n\nTägliche Prüfung eingeplant. Android kann den genauen Zeitpunkt durch Energiesparregeln verzögern.")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        AuthenticationContinuationHelper.onActivityResult(requestCode, resultCode, data)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 77)
        }
    }
}
