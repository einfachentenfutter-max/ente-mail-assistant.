package de.ente.mailassistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.microsoft.identity.client.*

class MorningReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val channelId = "morning_briefing"
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(
            NotificationChannel(channelId, "Outlook-Morgenbriefing", NotificationManager.IMPORTANCE_DEFAULT)
        )
        PublicClientApplication.createSingleAccountPublicClientApplication(
            context, R.raw.msal_config,
            object : IPublicClientApplication.ISingleAccountApplicationCreatedListener {
                override fun onCreated(app: ISingleAccountPublicClientApplication) {
                    app.acquireTokenSilentAsync(
                        arrayOf("https://graph.microsoft.com/Mail.Read", "https://graph.microsoft.com/User.Read"),
                        "https://login.microsoftonline.com/consumers",
                        object : SilentAuthenticationCallback {
                            override fun onSuccess(result: IAuthenticationResult) {
                                MailReader.fetchUnreadSummary(result.accessToken) { summary ->
                                    val short = summary.take(900)
                                    val notification = NotificationCompat.Builder(context, channelId)
                                        .setSmallIcon(android.R.drawable.ic_dialog_email)
                                        .setContentTitle("Dein Outlook-Morgenbriefing")
                                        .setStyle(NotificationCompat.BigTextStyle().bigText(short))
                                        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                                        .setAutoCancel(true)
                                        .build()
                                    try { NotificationManagerCompat.from(context).notify(700, notification) } catch (_: SecurityException) {}
                                    scheduleNext(context)
                                }
                            }
                            override fun onError(exception: com.microsoft.identity.client.exception.MsalException) {
                                notifyError(context, "Bitte Ente Mail Assistant öffnen und erneut anmelden.")
                                scheduleNext(context)
                            }
                        })
                }
                override fun onError(exception: com.microsoft.identity.client.exception.MsalException) {
                    notifyError(context, "Microsoft-Anmeldung konnte nicht geladen werden.")
                    scheduleNext(context)
                }
            })
    }

    private fun notifyError(context: Context, message: String) {
        val n = NotificationCompat.Builder(context, "morning_briefing")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Outlook-Morgenbriefing")
            .setContentText(message).setAutoCancel(true).build()
        try { NotificationManagerCompat.from(context).notify(701, n) } catch (_: SecurityException) {}
    }

    private fun scheduleNext(context: Context) = MorningScheduler.schedule(context)
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) MorningScheduler.schedule(context)
    }
}
